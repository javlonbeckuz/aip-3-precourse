# Chegirma, to‘lov, yetkazib berish va kafolat qoidalari

Manba: «Baraka Office» prays-listi (2026-yil 1-oktabr) va namunaviy shartnoma.
Narxlar QQS (12%) bilan.

## Chegirma

- Sotuv menejeri: buyurtma summasi 20 000 000 so‘mdan oshsa, prays-list narxidan 5% gacha chegirma bera oladi.
- Savdo bo‘limi rahbari (ROP): 100% oldindan to‘lov bo‘lsa yoki buyurtma 50 000 000 so‘mdan oshsa, yozma ruxsat bilan 10% gacha.
- 10% dan yuqori chegirma taqiqlanadi.
  Faqat 150 000 000 so‘mdan katta tenderlarda bosh direktor imzosi bilan ko‘rib chiqiladi.

## To‘lov

- Korporativ mijoz: shartnoma imzolangach 3 bank ish kuni ichida 70% oldindan to‘lov, qolgan 30% mebel topshirilgandan keyin 15 bank ish kuni ichida.
- Foizsiz 3 oyga bo‘lib to‘lash: faqat 50% boshlang‘ich to‘lov va bank kafolati (yoki lizing) bo‘lsa.

## Yetkazib berish va montaj

- Muddat: 70% (yoki 100%) oldindan to‘lov tushgan kundan 7 ish kuni.
  Maxsus o‘lchamdagi MDF/shpon buyurtmalar: 12 ish kuni.
- Toshkent shahri: buyurtma 10 000 000 so‘m va undan ko‘p bo‘lsa yetkazish va montaj bepul, kam bo‘lsa 350 000 so‘m.
- Toshkent viloyati va boshqa hududlar: Toshkent halqa yo‘lidan har 1 km uchun 8 000 so‘m.

## 3D dizayn-loyiha

- Buyurtma 15 000 000 so‘mdan oshsa, 24 soat ichida bepul 3D chizma.
- Kam bo‘lsa 500 000 so‘m; mebel sotib olinsa, bu summa umumiy narxdan chegiriladi.

## Kafolat

- Stol, shkaf va tumba korpuslari (LDSP, MDF, metall karkas): 24 oy.
- Kreslo mexanizmi, gazlift, g‘ildiraklar va harakatlanuvchi furnitura: 12 oy.
- Zavod nuqsoni aniqlansa: murojaatdan 5 ish kuni ichida bepul ta’mirlanadi yoki almashtiriladi.

## Qaytarish

- Standart katalogdagi mebel o‘rnatilmagan va qadog‘i buzilmagan bo‘lsa, 10 kalendar kun ichida almashtiriladi.
